# AndroidTable
**Работа с несколькими разметками**

![Screenshot](screenshot.png)
![Screenshot](screenshot2.png)
